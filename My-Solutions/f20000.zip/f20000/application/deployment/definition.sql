prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 20000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(32743468989832740)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'MY_FLOWS:MY_FORM_IMG:PKG_BPMN'
);
wwv_flow_imp.component_end;
end;
/
