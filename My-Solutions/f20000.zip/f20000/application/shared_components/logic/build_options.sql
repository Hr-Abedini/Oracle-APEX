prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 20000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(31521142222553982)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>55541243
);
wwv_flow_imp.component_end;
end;
/
