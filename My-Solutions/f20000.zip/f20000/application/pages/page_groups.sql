prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 20000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(31815514942554453)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
