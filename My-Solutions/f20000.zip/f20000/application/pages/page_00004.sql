prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'img in form - edit'
,p_alias=>'IMG-IN-FORM-EDIT'
,p_page_mode=>'MODAL'
,p_step_title=>'img in form - edit'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32307108184602612)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31643675753554121)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TILTE,',
'       IMG_FILE,',
'       IMG_FILENAME,',
'       IMG_MIMETYPE,',
'       IMG_LASTUPD',
'       --null IMG_CHARSET',
'  from MY_FORM_IMG'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32298410705490620)
,p_plug_name=>'img'
,p_parent_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(31633824733554110)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P4_ID is not null ',
'and',
'(',
'  select nvl(dbms_lob.getlength(IMG_FILE),0) ',
'  from MY_FORM_IMG ',
'  where id = :P4_ID',
') > 0'))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32299042262490626)
,p_plug_name=>'info'
,p_parent_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P4_ID is not null ',
'and',
'(',
'  select nvl(dbms_lob.getlength(IMG_FILE),0) ',
'  from MY_FORM_IMG ',
'  where id = :P4_ID',
') > 0'))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32312403934602631)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31585995921554056)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32312890722602631)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(32312403934602631)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(31698638855554189)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32298508464490621)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(32298410705490620)
,p_button_name=>'DELETE_IMAGE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(31698768361554190)
,p_button_image_alt=>'Delete Image'
,p_button_position=>'COPY'
,p_button_redirect_url=>unistr('javascript:apex.confirm(''\0622\06CC\0627 \0639\06A9\0633 \062D\0630\0641 \0634\0648\062F\061F'',''DELETE_IMAGE'');')
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32314256965602634)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(32312403934602631)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(31698638855554189)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32314634377602635)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(32312403934602631)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(31698638855554189)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32315043320602635)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(32312403934602631)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(31698638855554189)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32298129524490617)
,p_name=>'P4_IMG_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32299042262490626)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_prompt=>'New'
,p_source=>'IMG_FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32298247420490618)
,p_name=>'P4_IMG_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32299042262490626)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_prompt=>'New'
,p_source=>'IMG_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32298329244490619)
,p_name=>'P4_IMG_LASTUPD'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32299042262490626)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_prompt=>'New'
,p_source=>'IMG_LASTUPD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32298689456490622)
,p_name=>'P4_SHOW_IMG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(32298410705490620)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_source=>'IMG_FILE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_04=>'IMG_FILENAME'
,p_attribute_05=>'IMG_LASTUPD'
,p_attribute_07=>'IMG_MIMETYPE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32299525441490631)
,p_name=>'P4_IMG_FILE'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_prompt=>'Img File'
,p_source=>'IMG_FILE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'IMG_FILENAME'
,p_attribute_03=>'IMG_FILENAME'
,p_attribute_05=>'IMG_LASTUPD'
,p_attribute_06=>'Y'
,p_attribute_07=>unistr('\062F\0627\0646\0644\0648\062F')
,p_attribute_08=>'attachment'
,p_attribute_11=>'image/*'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32307533484602614)
,p_name=>'P4_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32307948900602620)
,p_name=>'P4_TILTE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_item_source_plug_id=>wwv_flow_imp.id(32307108184602612)
,p_prompt=>'Tilte'
,p_source=>'TILTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(31697411997554187)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32312970997602631)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(32312890722602631)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32313712715602634)
,p_event_id=>wwv_flow_imp.id(32312970997602631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32300186522490637)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(32307108184602612)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>32300186522490637
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32298719884490623)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\062D\0630\0641 \0639\06A9\0633')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update my_form_img ',
'    set IMG_FILE = null,         ',
'        IMG_FILENAME = null, ',
'        IMG_MIMETYPE = null, ',
'        IMG_LASTUPD = null',
'where id = :P4_ID;',
'',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32298508464490621)
,p_process_success_message=>unistr('\062D\0630\0641 \0628\0627 \0645\0648\0641\0642\06CC\062A \0627\0646\062C\0627\0645 \0634\062F')
,p_internal_uid=>32298719884490623
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32316221665602639)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>32316221665602639
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32315464525602637)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(32307108184602612)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form img in form - edit'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>32315464525602637
);
wwv_flow_imp.component_end;
end;
/
