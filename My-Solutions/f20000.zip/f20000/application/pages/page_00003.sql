prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Image in Form'
,p_alias=>'IMAGE-IN-FORM'
,p_step_title=>'Image in Form'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'td[headers="my-ir-col-img"] img {',
'    ',
'    width:120px; ',
'    height:120px; ',
'    object-fit:cover; ',
'    border-radius:8px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32317203363602642)
,p_plug_name=>'Image in Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31581358141554051)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "ID",',
'    "TILTE",',
'    --sys.dbms_lob.getlength("IMG_FILE")"IMG_FILE",',
'    case when "IMG_FILE" is not null then 1 end "IMG_FILE",',
'    case when "IMG_FILE" is not null then 1 end img,',
'    ',
'    "IMG_FILENAME",',
'    "IMG_MIMETYPE",    ',
'    "IMG_LASTUPD"',
'from "MY_FORM_IMG"'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Image in Form'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(32317305557602642)
,p_name=>'Image in Form'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:CR,:P4_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'902408'
,p_internal_uid=>32317305557602642
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32318071849602646)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32297835491490614)
,p_db_column_name=>'IMG'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>'Img'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:MY_FORM_IMG:IMG_FILE:ID::::::::'
,p_static_id=>'my-ir-col-img'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32318846441602648)
,p_db_column_name=>'IMG_FILE'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Img File'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:MY_FORM_IMG:IMG_FILE:ID::IMG_MIMETYPE:IMG_FILENAME:IMG_LASTUPD::attachment::'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32318450642602646)
,p_db_column_name=>'TILTE'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Tilte'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32297527516490611)
,p_db_column_name=>'IMG_FILENAME'
,p_display_order=>50
,p_column_identifier=>'I'
,p_column_label=>'Img Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32297618109490612)
,p_db_column_name=>'IMG_MIMETYPE'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Img Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32297779113490613)
,p_db_column_name=>'IMG_LASTUPD'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Img Lastupd'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(32323149977603159)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'323232'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TILTE:IMG:IMG_FILE:IMG_FILENAME:IMG_LASTUPD:IMG_MIMETYPE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32322580708602654)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31594816983554064)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31521737008553985)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(31700204418554192)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32320977045602651)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(32317203363602642)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(31698638855554189)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32321296726602651)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(32317203363602642)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32321747756602653)
,p_event_id=>wwv_flow_imp.id(32321296726602651)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32317203363602642)
);
wwv_flow_imp.component_end;
end;
/
