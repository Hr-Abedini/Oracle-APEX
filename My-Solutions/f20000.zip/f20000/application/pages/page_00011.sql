prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Show Password'
,p_alias=>'SHOW-PASSWORD'
,p_step_title=>'Show Password'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//------------------------------------------------------------',
'// Method 1',
'//------------------------------------------------------------',
'function togglePass(itemId, icon) {',
'    const pass = document.getElementById(itemId);',
'',
'    if (pass.type == ''password'') {        ',
'        pass.type = ''text'';',
'        icon.className = ''fa fa-eye'';',
unistr('        icon.title = ''\067E\0646\0647\0627\0646 \06A9\0631\062F\0646 \06AF\0630\0631\0648\0627\0698\0647'''),
'    }',
'    else {',
'        pass.type = ''password'';',
'        icon.className = ''fa fa-eye-slash'';',
unistr('        icon.title = ''\0646\0645\0627\06CC\0634 \06AF\0630\0631\0648\0627\0698\0647'''),
'    }',
'}',
'',
'//------------------------------------------------------------',
'// Method 2',
'//------------------------------------------------------------',
'function initPasswordToggle(passwordId, iconId) {',
'',
'    const pass = document.getElementById(passwordId);',
'    const icon = document.getElementById(iconId);',
'    const wrapper = pass.closest(''.t-Form-itemWrapper'');',
'',
'    // if (!pass || !icon || !wrapper) return;',
'',
'    function hide() {',
'        pass.type = ''password'';',
'        icon.className = ''fa fa-eye-slash'';',
unistr('        icon.title = ''\0646\0645\0627\06CC\0634 \06AF\0630\0631\0648\0627\0698\0647'';'),
'    }',
'',
'    function show() {',
'        pass.type = ''text'';',
'        icon.className = ''fa fa-eye'';',
unistr('        icon.title = ''\067E\0646\0647\0627\0646 \06A9\0631\062F\0646 \06AF\0630\0631\0648\0627\0698\0647'';'),
'    }',
'',
'    icon.addEventListener(''click'', function (e) {',
unistr('        // e.preventDefault(); // \062C\0644\0648\06AF\06CC\0631\06CC \0627\0632 \0631\0641\062A\0627\0631 \067E\06CC\0634\200C\0641\0631\0636'),
'        pass.type === ''password'' ? show() : hide();',
'        icon.focus(); ',
'    });',
'',
'    wrapper.addEventListener(''focusout'', function (e) {',
'        const focusTo = e.relatedTarget;',
'        ',
'        if (focusTo && wrapper.contains(focusTo)) {',
'            return;',
'        }',
'        hide();',
'    });',
'',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// \0641\0631\0627\062E\0648\0627\0646\06CC \0645\062A\062F'),
'initPasswordToggle(''P11_PASSWORD_2'', ''my-toggle-icon'');',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32885476753290807)
,p_name=>'P11_PASSWORD_1'
,p_item_sequence=>30
,p_prompt=>'Password - Method 1'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span',
'    style = "cursor: pointer;"',
'    class="fa fa-eye-slash"',
unistr('    title = ''\0646\0645\0627\06CC\0634 \06AF\0630\0631\0648\0627\0698\0647'''),
'    onClick = "togglePass(''P11_PASSWORD_1'', this)"',
'    >',
'    ',
'</span>'))
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(31696025568554185)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32885526645290808)
,p_name=>'P11_NOTE'
,p_item_sequence=>20
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.getElementById(''P11_PASSWORD'').value; ',
'',
'document.querySelector(''input[type="password"]'').value',
'',
''))
,p_prompt=>'console:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32885631562290809)
,p_name=>'P11_PASSWORD_2'
,p_item_sequence=>40
,p_prompt=>'Password - Lost focus'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span',
'    id="my-toggle-icon"',
'    tabindex="0"',
'    class="fa fa-eye-slash"',
unistr('    title="\0646\0645\0627\06CC\0634 \06AF\0630\0631\0648\0627\0698\0647"'),
'    style="cursor:pointer"',
'    onclick="return false;">',
'    ',
'</span>',
''))
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(31696025568554185)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
