prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>5488726071905790
,p_default_application_id=>20000
,p_default_id_offset=>0
,p_default_owner=>'HRA'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Numeric Up-Down'
,p_alias=>'NUMERIC-UP-DOWN'
,p_step_title=>'Numeric Up-Down'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/**',
unistr(' * \0627\06CC\062C\0627\062F \062D\0627\0644\062A +/- \06A9\0631\062F\0646 \0628\0647 \0641\06CC\0644\062F \0639\062F\062F\06CC'),
' * ',
' ** type: number field',
unistr(' ** \0628\0631\0627\06CC \0642\0631\0627\0631\06AF\0631\0641\062A\0646 \062F\06A9\0645\0647 > post text = *'),
' * ',
' * ',
unistr(' * @param itemName > \0646\0627\0645 \0622\06CC\062A\0645'),
unistr(' * @param wheel_step >  \0645\0642\062F\0627\0631\06CC \06A9\0647 \0628\0627 \0686\0631\062E \0645\0648\0633 \0628\0627\06CC\062F \0627\0636\0627\0641\0647/\06A9\0645 \0634\0648\062F'),
unistr(' * @param ud_step > up-down \0645\0642\062F\0627\0631\06CC \06A9\0647 \0628\0627\06CC\062F \0627\0636\0627\0641\0647/\06A9\0645 \0634\0648\062F'),
unistr(' * @param negative > \0628\0627\0634\062F false \062C\0644\0648\06AF\06CC\0631\06CC \0627\0632 \0645\0642\062F\0627\0631 \0645\0646\0641\06CC \0627\06AF\0631 \0645\0642\062F\0627\0631'),
unistr(' * @param groupingSymbol >  \06A9\0627\0631\0627\06A9\062A\0631 \062C\062F\0627\06A9\0646\0646\062F\0647 \0627\0631\0642\0627\0645 \0645\0648\0631\062F \0627\0633\062A\0641\0627\062F\0647'),
' */',
'function item_NumericSpinner(itemName, wheel_step = 10, ud_step = 1, negative = false, groupingSymbol = '','') {',
'',
'    //  ** css: btn-container-spin, btn-inc, btn-dec',
unistr('    // let btn = ''<div class="btn-container-spin">    <button type="button" class="btn-inc">\25B2</button>      <button type="button" class="btn-dec">\25BC</button>  </div>'''),
'    // let container = "#" + itemName + "_CONTAINER";',
'    // let containter$ = $("#" + itemName + "_CONTAINER .t-Form-itemText--post");',
'',
'    // containter$.html(btn);',
unistr('    // // \0628\0639\062F \0627\0632 \0627\0636\0627\0641\0647 \0634\062F\0646'),
'    // let btnUp$ = $(container + " .btn-inc");',
'    // let btnDown$ = $(container + " .btn-dec");',
'    //----------------------------------------------',
'    let containter$ = $("#" + itemName + "_CONTAINER .t-Form-itemText--post");',
'',
'    let css_btn = { background: "none", border: "none", cursor: "pointer" };',
'    let css_div = { display: "inline-flex", "flex-direction": "column", "vertical-align": "middle" };',
'',
'    let div$ = $(''<div>'').css(css_div);',
unistr('    let btnUp$ = $(''<button>'', { type: "button", text: ''\25B2'' }).css(css_btn);'),
unistr('    let btnDown$ = $(''<button>'', { type: "button", text: ''\25BC'' }).css(css_btn);'),
'',
'    div$.append(btnUp$);',
'    div$.append(btnDown$);',
'    containter$.html(div$);',
'    //----------------------------------------------',
'    let item$ = $("#" + itemName);',
'',
'    btnUp$.on("click", inc.bind(null, ud_step));',
'    btnDown$.on("click", dec.bind(null, ud_step));',
'',
'    item$.on("wheel", function (e) {',
'',
'        if (document.activeElement.id !== itemName) return;',
'',
'        e.preventDefault();',
'        let delta = e.originalEvent.deltaY;',
'',
'        if (delta < 0) {',
'            inc(wheel_step);',
'        } else {',
'            dec(wheel_step);',
'        }',
'',
'    });',
'',
'    function inc(step) {',
'        let val = parseFloat(item$.val().replace(groupingSymbol, '''')) || 0;',
'        item$.val(val + step);',
'        // apex.item(itemName).setValue(item$.val());',
'    }',
'',
'    function dec(step) {',
'        let val = parseFloat(item$.val().replace(groupingSymbol, '''')) || 0;',
'',
'        val = val - step',
'        if (negative == false & val < 0) val = 0;',
'',
'        item$.val(val);',
'        // apex.item(itemName).setValue(item$.val());         ',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'item_NumericSpinner(''P7_NO1'')',
'item_NumericSpinner(''P7_NO2'',5)',
'item_NumericSpinner(''P7_NO3'',2,2)',
'item_NumericSpinner(''P7_NO4'',5,1,true)',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32004027030435868)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31594816983554064)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31521737008553985)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(31700204418554192)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29461625957073643)
,p_name=>'P7_NO1'
,p_item_sequence=>20
,p_prompt=>'step: 1 , wheel: 10'
,p_post_element_text=>'*'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--postTextBlock'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29461707546073644)
,p_name=>'P7_NO2'
,p_item_sequence=>30
,p_prompt=>'step: 1 , wheel step: 5'
,p_post_element_text=>'*'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--postTextBlock'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29461833856073645)
,p_name=>'P7_NO3'
,p_item_sequence=>40
,p_prompt=>'step: 2 , wheel: 2'
,p_post_element_text=>'*'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--postTextBlock'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29462037309073647)
,p_name=>'P7_NO4'
,p_item_sequence=>50
,p_prompt=>'negative | step: 1 , wheel: 5'
,p_post_element_text=>'*'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(31696157817554185)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--postTextBlock'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp.component_end;
end;
/
